// javascript code for option operations in OPTIONS page

var defaultApiUrl = "https://cn.bing.com";

// wallpaper settings
function initWallpaperConf() {
	// show uhd wallpaper
	if (readConf('enable_uhd_wallpaper') == 'no') {
		document.getElementById('use-uhd-wallpaper-checkbox').checked = false;
	}
	else {
		document.getElementById('use-uhd-wallpaper-checkbox').checked = true;
	}
}

function changeWallpaperConf() {
	// update uhd wallpaper conf
	if (document.getElementById('use-uhd-wallpaper-checkbox').checked == true) {
		writeConf('enable_uhd_wallpaper', 'yes');
	}
	else {
		writeConf('enable_uhd_wallpaper', 'no');
	}
	// change wallpaper_data conf to trigger wallpaper reload when open a new tab
	writeConf('wallpaper_date', '1970-01-01');
	alert(i18n('op_saved_alert'));
}

// api settings
function initApiConf() {
	// api url
	document.getElementById('api-textarea').value = readConf('api_url');
}

function changeApiConf() {
	// update api url conf
	var newConf = document.getElementById('api-textarea').value;
	// change api_url conf to trigger api reload when open a new tab
	writeConf('api_url', newConf);
	alert(i18n('op_saved_alert'));
}

function recoverDefaultApiConf() {
	var cfm = confirm(i18n('op_reset_default_confirm_alert'));
	if (cfm == true) {
		// default api url conf
		writeConf('api_url', defaultApiUrl);
		document.getElementById('api-textarea').value = defaultApiUrl;
		alert(i18n('op_reset_default_done_alert'));
	}
}

// ------------- exec --------------

// init wallpaper
initWallpaperConf();

// bind save wallpaper conf btn
document.getElementById('save-wallpaper-conf-btn').onclick = changeWallpaperConf;

// read api conf
initApiConf();

// bind save api conf
document.getElementById('save-api-conf').onclick = changeApiConf;
document.getElementById('recover-api-conf').onclick = recoverDefaultApiConf;